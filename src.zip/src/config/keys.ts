export default {
  mongoURI:
    'mongodb+srv://MKAssassin:MK348@learnnestjs.i0oeg.mongodb.net/moyyn_companies?retryWrites=true&w=majority&authenticationDatabase=admin',
};
